from json import loads

import requests
from bs4 import BeautifulSoup


def request(url=None, use_proxy=None):
    header = {
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome\
        /55.0.2883.95 Safari/537.36",
        "accept-language": "en-US,en;q=0.8",
        "X-Proxy-Country": "US"
    }

    # Proxy Request
    try:
        if str(use_proxy) == str("True"):
            raw_proxy = "charityengine.services:20000"  # workdistribute.charityengine.com:20000/charityengine.services
            ce_proxies = {"https": "https://41b129a39e6c4a1db44a795691a0b6af: @" + raw_proxy,
                          "http": "http://41b129a39e6c4a1db44a795691a0b6af: @" + raw_proxy}
            proxies = {"proxy": ce_proxies}
            req = requests.request('GET', url=url, headers=header, timeout=25, verify=False, proxies=proxies['proxy'])
            if req.status_code == 200:
                return req.content
            else:
                return {'error': 'request failed: not 200',
                        'url': url,
                        'use_proxy': 'true'}

        # Non Proxy Request
        else:
            req = requests.request('GET', url=url, headers=header, timeout=25, verify=False)
            if req.status_code == 200:
                return req.content
            else:
                return {'error': 'request failed: not 200',
                        'url': url,
                        'use_proxy': 'false'}
    except:
        return {'error': 'request failed: request function try except',
                'url': url,
                'use_proxy': str(use_proxy)}


def parse_ins(req_content=None):
    try:
        html = req_content.text.encode("utf-8")
        text = html[html.index(str("window._sharedData = ").encode("utf-8")) + 21:]
        text = (text[:text.index(str("};</script>").encode("utf-8"))] + str("}").encode("utf-8")).replace(
            str('\\"').encode("utf-8"), str("").encode("utf-8"))
        dictionary = loads(text)
        # data = dictionary["entry_data"]["ProfilePage"][0]["user"]
        return dictionary
    except:
        return {'error': 'parse ins function try except'}


def parse_ytb(req_content=None):
    try:
        soup = BeautifulSoup(req_content, 'html.parser')
        try:
            related_links = [li.find('a').get('href') for li in soup.findAll('li', {'class': 'channel-links-item'})]
        except:
            related_links = None
        try:
            stats = '; '.join([span.text for span in soup.find('div', {'class': 'about-stats'}).findAll('span')])
        except:
            stats = None
        try:
            descr = soup.find('pre').text
        except:
            descr = None
        try:
            country = soup.find('span', {'class': 'country-inline'}).text
        except:
            country = None
        try:
            biz_email = True if soup.find('span', {'class': 'business-email-label'}) else False
        except:
            biz_email = None
        try:
            similar_links = [a.get('href') for a in soup.find_all('a', class_='ux-thumb-wrap')]
        except:
            similar_links = None

        details_dict = {'related_links': related_links,
                        'stats': stats,
                        'descr': descr,
                        'country': country,
                        'biz_email': biz_email,
                        'similar_links': similar_links}
        return details_dict
    except:
        return {'error': 'parse ytb function try except'}


def lambda_handler(event, context):

    try:
        if str(event['social_type']) == str("ins"):
            url = str("https://www.instagram.com/") + str(event['username']) + str("/")
            content = request(url=url, use_proxy=event['use_proxy'])
            parse_ins(req_content=content)
        elif str(event['social_type']) == str("ytb"):
            url = str("https://www.youtube.com/user/") + str(event['username'])
            content = request(url=url, use_proxy=event['use_proxy'])
            parse_ytb(req_content=content)
    except Exception as e:
        return {'error': 'handler function try except'+str(e)}
